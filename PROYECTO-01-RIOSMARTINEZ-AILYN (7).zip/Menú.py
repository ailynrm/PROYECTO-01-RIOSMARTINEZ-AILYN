if __name__ == "__main__":

    USUARIO = 'Lifestoreadmin1'
    CONTRASENA = '%123%'

    INTENTOS = 3

    while True:

        if INTENTOS == 0:

            exit()
        username = input('Ingrese su nombre de usuario:\n > ')
        password = input('Ingrese la contraseña:\n > ')
        
        if username == "Lifestoreadmin1":

            if password == "%123%":
               
                break
        else:
            
            INTENTOS = INTENTOS -1
           
            print(f'\n!! Usuario/Contraseña incorrecto(s), {INTENTOS} restantes !!\n')
    
    print(f"\n\n\n {USUARIO} ha iniciado sesión")

    print(""" BIENVENIDO A LIFESTORE""")
    dialog = [
      """\tSelecciona la información que deseas consultar""",
      'Productos más vendidos',
      'Productos más buscados',
      'Productos menos vendidos',
      'Productos menos buscados',
      'Productos mejor evaluados',
      'Productos peor evaluados',
      'Meses con mayores ventas',
      'Meses con menores ventas']
  

separado = ['⥼', '⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯', '⥽']
separador = separado[0] + separado[1] + separado[2]

opciones =[
    'Productos más vendidos',
    'Productos más buscados',
    'Productos menos vendidos',
    'Productos menos buscados',
    'Productos mejor evaluados',
    'Productos peor evaluados',
    'Meses con mayores ventas',
    'Meses con menores ventas']
Productos_mas_vendidos = [
  ''
 ]
Productos_mas_buscados = [
  ''
]
Productos_menos_vendidos = [
  ''
  ]
Productos_menos_buscados = [
  ''
  ]
Productos_mejor_evaluados = [
    ''
]
Productos_peor_evaluados = [
  ''
]

Meses_con_mayores_ventas = [

]

Meses_con_menores_ventas = [

]

Productos_mas_vendidos.sort()
Productos_mas_buscados.sort()
Productos_menos_vendidos.sort()
Productos_menos_buscados.sort()
Productos_mejor_evaluados.sort()
Productos_peor_evaluados.sort()
Meses_con_mayores_ventas.sort()
Meses_con_menores_ventas.sort()

seleccion = 0
while True:
    listaDeOpciones = ''
    indice = 1
    indicacion = '\t'
    #Menú
    if seleccion == 0:
        indicacion += 'Ir a:'
        for opcion in opciones:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{indice}{vineta} ' + opcion + '\n'
            indice += 1
    #Productos_mas_vendidos
    if seleccion == 1:
        indicacion += 'Productos más vendidos'
        for productomasvendido in productos_mas_vendidos:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'

            listaDeOpciones += f'{vineta}{vineta} ' + productomasvendido + '\n'
            indice += 1
    
    #Productos_mas_buscados
    if seleccion == 2:
        # listaDeOpciones = ''
        # indice = 1
        indicacion = '\t Productos más buscados'
        for Productosmasbuscados in Productos_mas_buscados:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{indice}{vineta} ' + Productosmasbuscados + '\n'
            indice += 1
    
    #Productos_menos_vendidos
    if seleccion == 3:
        # listaDeOpciones = ''
        # indice = 1
        indicacion = '\tProductos menos vendidos:'
        for Productosmenosvendidos in Productos_menos_vendidos:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{vineta} ' + Productosmenosvendidos + '\n'
            indice += 1

    #Productos_menos_buscados
    if seleccion == 4:
        # listaDeOpciones = ''
        # indice = 1
        indicacion = '\tProductos menos buscados:'
        for Productosmenosbuscados in Productos_menos_buscados:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{vineta} ' + Productosmenosbuscados + '\n'
            indice += 1

   #Productos_mejor_evaluados
    if seleccion == 4:
        # listaDeOpciones = ''
        # indice = 1
        indicacion = '\tProductos mejor evaluados:'
        for Productosmejorevaluados in Productos_mejor_evaluados:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{vineta} ' + Productosmejorevaluados + '\n'
            indice += 1
    
    #Meses_con_mayores_ventas
    if seleccion == 4:
        # listaDeOpciones = ''
        # indice = 1
        indicacion = '\tMeses con mayores ventas:'
        for Mesesconmayoresventas in Meses_con_mayores_ventas:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{vineta} ' + 
            Mesesconmayoresventas + '\n'
            indice += 1

    #Meses_con_menores_ventas
    if seleccion == 4:
        # listaDeOpciones = ''
        # indice = 1
        indicacion = '\tMeses con menores ventas:'
        for Mesesconmenoresventas in Meses_con_menores_ventas:
            if indice % 2:
                vineta = '✦'
            else:
                vineta = '✧'
            listaDeOpciones += f'{vineta}{vineta} ' + Mesesconmenoresventas + '\n'
            indice += 1


    # Dialogo, indicación, lista de opciones
    print(dialog[seleccion])
    print(separador)
    print(indicacion)
    print(listaDeOpciones)
    a = f'{" " * (len(separado[1]) - 3)}'
    seleccion = input(a + '・➣ ')
    if seleccion == 'e':
        break
    seleccion = int(seleccion)





    