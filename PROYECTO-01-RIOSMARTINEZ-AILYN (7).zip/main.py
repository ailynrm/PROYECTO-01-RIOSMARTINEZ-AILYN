if __name__ == "__main__":

    USUARIO = 'Lifestoreadmin1'
    CONTRASENA = '%123%'

    INTENTOS = 3

    while True:

        if INTENTOS == 0:

            exit()
        username = input('Ingrese su nombre de usuario:\n > ')
        password = input('Ingrese la contraseña:\n > ')
        
        if username == "Lifestoreadmin1":

            if password == "%123%":
               
                break
        else:
            
            INTENTOS = INTENTOS -1
           
            print(f'\n!! Usuario/Contraseña incorrecto(s), {INTENTOS} restantes !!\n')
    
    print(f"\n\n\n {USUARIO} ha iniciado sesión")

from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches

# VENTAS VÁLIDAS
ventas = []
for sale in lifestore_sales:
    refund = sale[-1]
    if refund == 1:
        continue
    else:
        ventas.append(sale)

for venta in ventas:
    print(venta)

meses = [
    '/01/', '/02/', '/03/', '/04/', '/05/', '/06/',
    '/07/', '/08/', '/09/', '/10/', '/11/', '/12/'
    ]
    
ventas_por_mes = []
for mes in meses:
    lista_vacia = []
    ventas_por_mes.append(lista_vacia)

for venta in ventas:
    id_venta = venta[0]
    fecha = venta[3]

    contador_de_mes = 0

    for mes in meses:
        if mes in fecha:
            ventas_por_mes[contador_de_mes].append(id_venta)
            continue
        contador_de_mes = contador_de_mes + 1 

contador_de_mes = 0
for venta_mensual in ventas_por_mes:
    print(f'En el mes de {meses[contador_de_mes]} hubo {len(venta_mensual)} ventas')
    contador_de_mes = contador_de_mes + 1

# GANANCIAS MENSUALES
ganacias_mensuales = []
for venta_mensual in ventas_por_mes:
    ganancia_del_mes = 0
    for id_venta in venta_mensual:
        indice_de_venta = id_venta - 1
        info_de_venta = lifestore_sales[indice_de_venta]

        id_prod = info_de_venta[1]
        indice_de_prod = id_prod - 1
        info_del_prod = lifestore_products[indice_de_prod]
        precio_de_prod = info_del_prod[2]
        ganancia_del_mes = ganancia_del_mes + precio_de_prod
    ganacias_mensuales.append(ganancia_del_mes)

lista_prev = []
for mes, ganancia in enumerate(ganacias_mensuales):
    sublista = [ganancia, mes]
    lista_prev.append(sublista)

for lista in lista_prev:
  lista_prev.sort(reverse=True)

for lista in lista_prev:
  print("Ganancias mensuales", lista)

#GANANCIA ANUAL
ingresos_anuales = 0
for ganancia_anio in lista_prev:
  ingreso_anio = ganancia_anio[0]
  ingresos_anuales += ingreso_anio
print("Ganancia total anual", ingresos_anuales)

#VENTAS MENSUALES
cantidad_ventas_mensuales = []
for mes, venta_mensual in enumerate(ventas_por_mes):
    cant_ventas_mensuales = len(venta_mensual)
    sublist = [cant_ventas_mensuales, mes]
    cantidad_ventas_mensuales.append(sublist)

for cant in cantidad_ventas_mensuales:
  cantidad_ventas_mensuales.sort(reverse=True)
for par in cantidad_ventas_mensuales:
   print("Ventas mensuales", par)

#VENTAS ANUALES
venta_anual = 0
for venta in cantidad_ventas_mensuales:
    ingreso = venta[0]
    venta_anual += ingreso
print("Ventas anuales", venta_anual)

#RESEÑAS
prod_reviews=[ ]
for prod in lifestore_products:
    id_producto=prod[0]
    sublista=[id_producto,0,0]
    prod_reviews.append(sublista)

for venta in lifestore_sales:
    id_prod= venta[1]
    review= venta[2]
   
    indice= id_prod - 1
    prod_reviews[indice][1]+=review
    prod_reviews[indice][2]+=1

for indice, lista in enumerate(prod_reviews):
    suma=lista[1]
    cant=lista[2]
    if cant>0:
        calif_prom= suma/cant
        prod_reviews[indice][1]=calif_prom

#mejores calificados
mejores_calificados=[ ]
peores_calificados = []
for lista in prod_reviews:
    sublist=[lista[1], lista[0]]  
    mejores_calificados.append(sublist)  
    peores_calificados.append(sublist)
    
mejores_calificados.sort(reverse=True)
print('Los 5 productos con mejor calificación son:')
for rev in mejores_calificados[:5]:
    print(rev)
  
peores_calificados.sort(reverse=True)
print('Los productos con peor calificación son:')
for rev in peores_calificados:
  if rev in peores_calificados[-58:]:
    print(rev)

#MEJORES Y PEORES VENDIDOS
mejores_vendidos= []
perores_vendidos = []
for lista in prod_reviews:
    sublista = [lista[2], lista[0], lista[1]]
    mejores_vendidos.append(sublista)

mejores_vendidos.sort(reverse=True)
for rev in mejores_vendidos[:5]:
    print("Mejores vendidos", rev) 

for lista in prod_reviews:
    sublista = [lista[2], lista[0], lista[1]]
    perores_vendidos.append(sublista)

perores_vendidos.sort(reverse=True)
for rev in perores_vendidos[-54:]:
    print("Peores vendidos", rev)
